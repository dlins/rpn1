#include "TrivialAccumulation_Params.h"

TrivialAccumulation_Params::TrivialAccumulation_Params() : AccumulationParams(){
}

TrivialAccumulation_Params::~TrivialAccumulation_Params(){
}

