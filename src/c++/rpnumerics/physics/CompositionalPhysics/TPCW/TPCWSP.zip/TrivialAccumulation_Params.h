#ifndef _TRIVIALACCUMULATION_PARAMS_
#define _TRIVIALACCUMULATION_PARAMS_

#include <stdlib.h>

#include "AccumulationParams.h"

class TrivialAccumulation_Params : public AccumulationParams {
    private:
    protected:
    public:
        TrivialAccumulation_Params();
        ~TrivialAccumulation_Params();
};

#endif //_TRIVIALACCUMULATION_PARAMS_

