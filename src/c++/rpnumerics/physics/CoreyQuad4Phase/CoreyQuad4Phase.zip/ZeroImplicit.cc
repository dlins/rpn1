#include "ZeroImplicit.h"

ZeroImplicit::ZeroImplicit(){
}

ZeroImplicit::~ZeroImplicit(){
}

